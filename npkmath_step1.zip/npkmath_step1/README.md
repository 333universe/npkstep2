# NPKmath step 1: a verifier you can trust

What changed
- npkmath/engine.py   real verifier: exact symbolic check + 50-digit numeric cross-check.
                      REFUTED always carries a counterexample. matrix_verify reads its inputs.
- npkmath/signals.py  your module, fixed: stale freshness, summary side effects, proofs decaying,
                      REFUTED shown as "verified". Adds claim_holds + timeless fields.
- npkmath/pipeline.py emits signals with MEASURED time/precision (no more 0.0).
- npkmath/benchmark.py 53 labelled claims. Goal: 0 critical errors, 0 false assurance.
- tests/              your original 27 tests, unchanged, plus 16 regression tests.
- pyproject.toml      makes `pip install -e ".[dev]"` work (CI needs it).

Run in Colab: upload this zip, then open run_step1.ipynb (or run the cells in order).

Next step: LLM-in-the-loop. Ask a model the benchmark claims with and without
export_for_prompt() context, and log REAL outcomes with log_ai_feedback.
